const require = (await import('node:module')).createRequire(import.meta.url); const __chunk_filename = (await import('node:url')).fileURLToPath(import.meta.url); const __chunk_dirname = (await import('node:path')).dirname(__chunk_filename);
import {
  DEFAULT_PORT,
  getBinaryPath,
  isServerRunning
} from "./chunk-3QYYWWO5.js";
import "./chunk-QTEJYYEH.js";
import {
  debugLogger
} from "./chunk-GPVT36PL.js";
import "./chunk-6HI7VNOG.js";
import "./chunk-TUDYL3X4.js";
import "./chunk-IUUIT4SU.js";
import "./chunk-34MYV7JD.js";

// packages/cli/src/services/liteRtServerManager.ts
import fs from "node:fs";
var LiteRtServerManager = class {
  static async ensureRunning(gemmaSettings) {
    if (!gemmaSettings?.enabled) return;
    if (gemmaSettings.autoStartServer === false) return;
    const binaryPath = getBinaryPath();
    if (!binaryPath || !fs.existsSync(binaryPath)) {
      debugLogger.log(
        '[LiteRtServerManager] Binary not installed, skipping auto-start. Run "gemini gemma setup".'
      );
      return;
    }
    const port = parseInt(
      gemmaSettings.classifier?.host?.match(/:(\d+)/)?.[1] ?? "",
      10
    ) || DEFAULT_PORT;
    const running = await isServerRunning(port);
    if (running) {
      debugLogger.log(
        `[LiteRtServerManager] Server already running on port ${port}`
      );
      return;
    }
    debugLogger.log(
      `[LiteRtServerManager] Auto-starting LiteRT server on port ${port}...`
    );
    try {
      const { startServer } = await import("./start-4ZVBGDBV.js");
      const started = await startServer(binaryPath, port);
      if (started) {
        debugLogger.log(`[LiteRtServerManager] Server started on port ${port}`);
      } else {
        debugLogger.warn(
          `[LiteRtServerManager] Server may not have started correctly on port ${port}`
        );
      }
    } catch (error) {
      debugLogger.warn("[LiteRtServerManager] Auto-start failed:", error);
    }
  }
};
export {
  LiteRtServerManager
};
/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
